package com.example.sareeqr

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("sarees", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var articleInput: EditText
    private lateinit var priceInput: EditText
    private var selectedPhoto: Uri? = null
    private var preview: PreviewView? = null
    private var scanned = false

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { selectedPhoto = uri; Toast.makeText(this, "Photo selected", Toast.LENGTH_SHORT).show() }
    }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startScanner() else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 24); setBackgroundColor(Color.rgb(247,242,234))
    }
    private fun title(text: String) = TextView(this).apply { this.text=text; textSize=28f; setTextColor(Color.rgb(75,48,40)); gravity=Gravity.CENTER; setPadding(0,8,0,24) }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text=text; setOnClickListener{action()} }

    private fun showHome() {
        val box=base(); box.addView(title("SAREE QR"))
        val sub=TextView(this).apply { text="Free • Offline • No website/server\nPhoto + Article No. + Price only"; textSize=16f; gravity=Gravity.CENTER; setPadding(0,0,0,24) }; box.addView(sub)
        box.addView(button("ADD SAREE") { showAdd() }, LinearLayout.LayoutParams(-1,60))
        box.addView(button("SCAN SAREE QR") { requestScanner() }, LinearLayout.LayoutParams(-1,60))
        box.addView(button("SAVED SAREES") { showSaved() }, LinearLayout.LayoutParams(-1,60))
        setContentView(box)
    }

    private fun showAdd() {
        val box=base(); box.addView(title("ADD SAREE"))
        val pick=button("CHOOSE MAIN PHOTO") { photoPicker.launch("image/*") }; box.addView(pick)
        articleInput=EditText(this).apply { hint="Article No."; textSize=18f; singleLine=true; setPadding(16,8,16,8) }; box.addView(articleInput)
        priceInput=EditText(this).apply { hint="Price"; textSize=18f; inputType=2; singleLine=true; setPadding(16,8,16,8) }; box.addView(priceInput)
        box.addView(button("GENERATE & SAVE QR") { saveProduct() })
        box.addView(button("BACK") { showHome() })
        setContentView(box)
    }

    private fun saveProduct() {
        val article=articleInput.text.toString().trim(); val price=priceInput.text.toString().trim(); val uri=selectedPhoto
        if(article.isEmpty() || price.isEmpty() || uri==null) { Toast.makeText(this,"Photo, Article No. and Price teeno bharein",Toast.LENGTH_LONG).show(); return }
        val key=cleanKey(article)
        try {
            val dest=File(filesDir,"saree_$key.jpg")
            contentResolver.openInputStream(uri).use { input -> FileOutputStream(dest).use { out -> input!!.copyTo(out) } }
            prefs.edit().putString("article_$key",article).putString("price_$key",price).putString("photo_$key",dest.absolutePath).apply()
            val qr=makeQr("SAREEQR:$key")
            saveAndShareQr(qr,key)
            Toast.makeText(this,"Saree saved",Toast.LENGTH_SHORT).show()
        } catch(e:Exception) { Toast.makeText(this,"Save failed: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun cleanKey(s:String)=s.uppercase().replace("[^A-Z0-9_-]".toRegex(),"_")

    private fun makeQr(text:String): Bitmap {
        val size=900; val matrix:BitMatrix=MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,size,size)
        val bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888)
        for(x in 0 until size) for(y in 0 until size) bmp.setPixel(x,y,if(matrix[x,y]) Color.BLACK else Color.WHITE)
        return bmp
    }

    private fun saveAndShareQr(bitmap:Bitmap,key:String) {
        val dir=File(cacheDir,"qr").apply{mkdirs()}; val file=File(dir,"QR_$key.png")
        FileOutputStream(file).use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
        val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",file)
        val intent=Intent(Intent.ACTION_SEND).apply{type="image/png";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
        startActivity(Intent.createChooser(intent,"QR save/share karein"))
    }

    private fun requestScanner() {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startScanner() else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun startScanner() {
        scanned=false; val root=FrameLayout(this); preview=PreviewView(this); root.addView(preview,FrameLayout.LayoutParams(-1,-1))
        val hint=TextView(this).apply{text="QR ko frame ke andar rakhein";textSize=17f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(20,18,20,18);setBackgroundColor(0x99000000.toInt())}
        val lp=FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM);lp.setMargins(24,0,24,60);root.addView(hint,lp);setContentView(root)
        val future=ProcessCameraProvider.getInstance(this); future.addListener({
            val provider=future.get(); val pv=preview!!
            val p=Preview.Builder().build().also{it.surfaceProvider=pv.surfaceProvider}; val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build(); val scanner=BarcodeScanning.getClient()
            analysis.setAnalyzer(executor){proxy->
                val media=proxy.image
                if(media!=null && !scanned){ val image=InputImage.fromMediaImage(media,proxy.imageInfo.rotationDegrees); scanner.process(image).addOnSuccessListener{codes-> val v=codes.firstOrNull()?.rawValue; if(!v.isNullOrBlank()){scanned=true;runOnUiThread{showProduct(v)}}}.addOnCompleteListener{proxy.close()} } else proxy.close()
            }
            provider.unbindAll();provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,p,analysis)
        },ContextCompat.getMainExecutor(this))
    }

    private fun showProduct(raw:String) {
        val key=raw.removePrefix("SAREEQR:").trim(); val article=prefs.getString("article_$key",null); val price=prefs.getString("price_$key",null); val path=prefs.getString("photo_$key",null)
        if(article==null || price==null || path==null){Toast.makeText(this,"Ye QR is phone ke saved sarees me nahi hai",Toast.LENGTH_LONG).show();showHome();return}
        val box=base();box.setBackgroundColor(Color.WHITE);box.addView(title("SAREE"))
        val image=ImageView(this).apply{setImageURI(Uri.fromFile(File(path)));scaleType=ImageView.ScaleType.FIT_CENTER};box.addView(image,LinearLayout.LayoutParams(-1,0,1f))
        box.addView(TextView(this).apply{text=article;textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(55,40,35));setPadding(0,14,0,4)})
        box.addView(TextView(this).apply{text="₹$price/-";textSize=26f;gravity=Gravity.CENTER;setTextColor(Color.rgb(55,40,35));setPadding(0,0,0,14)})
        box.addView(button("SCAN ANOTHER") { requestScanner() });box.addView(button("HOME") { showHome() });setContentView(box)
    }

    private fun showSaved() {
        val box=base();box.addView(title("SAVED SAREES")); val keys=prefs.all.keys.filter{it.startsWith("article_")}.sorted()
        if(keys.isEmpty()) box.addView(TextView(this).apply{text="Abhi koi saree saved nahi hai.";textSize=18f;gravity=Gravity.CENTER})
        else for(k in keys){val key=k.removePrefix("article_"); val a=prefs.getString(k,key)!!; val p=prefs.getString("price_$key","")!!;box.addView(button("$a   ₹$p/-") { showProduct("SAREEQR:$key") })}
        box.addView(button("HOME") { showHome() });setContentView(box)
    }

    override fun onDestroy(){executor.shutdown();super.onDestroy()}
}
