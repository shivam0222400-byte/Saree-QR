# Saree QR — Free Offline Android App

Features:
- Add saree: choose one main photo, Article No., Price.
- Generate QR containing only a local product ID.
- Scan QR and show only photo + Article No. + Price.
- Saved products work offline; no website, hosting or monthly server required.
- QR is shared as a PNG so it can be printed.

Demo image included: `demo_saree.png` from the user's supplied saree photo.

Build: Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).
